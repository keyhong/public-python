# -*- coding: utf-8 -*-
"""
   tossi.__about__
   ~~~~~~~~~~~~~~~
"""
__version__ = '0.3.1'
__license__ = 'BSD'
__author__ = 'What! Studio'
__maintainer__ = 'Heungsub Lee'
__maintainer_email__ = 'sub@nexon.co.kr'
