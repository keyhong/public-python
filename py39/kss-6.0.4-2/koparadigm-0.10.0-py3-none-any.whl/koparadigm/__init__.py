# -*- coding: utf-8 -*-
r"""KoParadigm
"""
from __future__ import absolute_import

from .koparadigm import Paradigm, prettify