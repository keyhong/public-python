from __future__ import absolute_import

from .g2pM import G2pM