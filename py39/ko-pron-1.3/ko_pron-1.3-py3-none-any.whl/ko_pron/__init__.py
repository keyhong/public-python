name = "ko_pron"

from .ko_pron import romanise, decompose_jamo
