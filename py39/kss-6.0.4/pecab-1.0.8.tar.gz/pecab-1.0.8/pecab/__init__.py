from pecab._pecab import PeCab

__ALL__ = [PeCab]
__version__ = "1.0.8"
__author__ = "Hyunwoong Ko"
