import distance
from kss._utils.sanity_checks import _check_type

