# -*- coding: utf-8 -*-
r"""word2word
"""
from __future__ import absolute_import

from .word2word import Word2word
