.. -*- mode: rst -*-



People
------

.. hlist::

  * `Florian Gardin <florian.GARDIN_EXT@bpce.fr>`_
  * `Ronan Gautier <Ronan.GAUTIER@bpce.fr>`_
  * `Nicolas Goix <Nicolas.GOIX_EXT@bpce.fr>`_
  * `Bibi Ndiaye <Bibi.NDIAYE@bpce.fr>`_
  * `Jean-Matthieu Schertzer <jean-mathieu.SCHERTZER_EXT@bpce.fr>`_
  
Please do not email the authors directly to ask for assistance or report issues.
Instead, please open an issue on GitHub.
