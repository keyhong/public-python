class ExperimentalWarning(Warning):
    """Used to manage warning messages for any experimental integrations."""

    pass
