Changelog
=========

0.2.1
-----

*Date: 2013-02-26*

* Improved Python compatibility (2.6, <=3.1).

0.2.0
-----

*Date: 2013-02-21*

* Fixed the explicit unicode literal issue on Python 3.2.
* Tested on Travis CI for Python 2.7, 3.2, 3.3 and PyPy.

0.1.0
-----

*Date: 2013-02-12*

0.0.2
-----

*Date: 2013-01-29*

* Fixed #1.

0.0.1
-----

*Date: 2012-12-06*

* Initial release.
