from .ipadic import DICDIR, VERSION, MECAB_ARGS
