from .hdftools import save_dict, load_dict

__all__ = ["save_dict", "load_dict"]
