from ._voting import VotingSelector

__all__ = ["VotingSelector"]
